#!/usr/bin/env bash
# Menerapkan fox-fix-bundle.zip ke repo Fabric (jalankan dari root repo). Aman dijalankan berulang kali.
set -euo pipefail
BUNDLE="${1:-fox-fix-bundle.zip}"
WORK="$(mktemp -d)"
unzip -q -o "$BUNDLE" -d "$WORK"
GEO=common/src/main/java/com/micaftic/morpher/resource/YsmGeometryParsing.java
# ConfigPolicies ada di common/ (1.21.1) atau fabric/ (26.x); patch-config-policies.py mencari sendiri

# 1) poly_mesh: timpa file baru (common/)
if [ -f common/src/main/java/com/micaftic/morpher/resource/PolyMeshBaker.java ] && grep -q "bakePolyMesh" "$GEO"; then
  echo "poly_mesh sudah ada di repo, dilewati."
else
  cp -r "$WORK/overlay/." .
fi

# 2) Mode hemat RAM: edit ConfigPolicies di tempatnya (BUKAN salin file kedua -> itu penyebab 'duplicate class')
python3 "$WORK/patch-config-policies.py"

# 3) Shading halus per titik untuk poly_mesh (RawFace/BakedQuad + 3 jalur render)
python3 "$WORK/patch-smooth-normals.py"

# 4) Pengecekan akhir
grep -q "bakePolyMesh" "$GEO" || { echo "::error::perbaikan poly_mesh gagal diterapkan"; exit 1; }
test -f common/src/main/java/com/micaftic/morpher/resource/PolyMeshBaker.java || { echo "::error::PolyMeshBaker.java tidak ada"; exit 1; }
grep -q "vertexNormals" common/src/main/java/com/micaftic/morpher/resource/pojo/RawYsmModel.java || { echo "::error::shading halus gagal diterapkan"; exit 1; }
grep -rq "isLowMemoryHeap" --include=ConfigPolicies.java common fabric || { echo "::error::mode hemat RAM gagal diterapkan"; exit 1; }
if [ "$(find . -name ConfigPolicies.java -not -path './.git/*' | wc -l)" -ne 1 ]; then
  echo "::error::ConfigPolicies.java ganda"; find . -name ConfigPolicies.java -not -path './.git/*'; exit 1
fi
echo "Selesai: poly_mesh + mode hemat RAM aktif."
