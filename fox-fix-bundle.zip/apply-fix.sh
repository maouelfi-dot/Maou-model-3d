#!/usr/bin/env bash
# Menerapkan fox-fix-bundle.zip ke repo (jalankan dari root repo). Aman dijalankan berulang kali.
set -euo pipefail
BUNDLE="${1:-fox-fix-bundle.zip}"
WORK="$(mktemp -d)"
unzip -q -o "$BUNDLE" -d "$WORK"
GEO=common/src/main/java/com/micaftic/morpher/resource/YsmGeometryParsing.java

if [ -f common/src/main/java/com/micaftic/morpher/resource/PolyMeshBaker.java ] && grep -q "bakePolyMesh" "$GEO"; then
  echo "Perbaikan sudah ada di repo, dilewati."
  exit 0
fi

if git apply --3way --whitespace=nowarn "$WORK/fox-fix.patch" 2> "$WORK/apply.err"; then
  echo "Patch berhasil diterapkan."
else
  echo "Patch tidak cocok ($(head -n1 "$WORK/apply.err")), pakai cara timpa file (overlay)."
  git reset -q --hard HEAD || true
  cp -r "$WORK/overlay/." .
fi

grep -q "bakePolyMesh" "$GEO" || { echo "::error::perbaikan poly_mesh gagal diterapkan"; exit 1; }
test -f common/src/main/java/com/micaftic/morpher/resource/PolyMeshBaker.java || { echo "::error::PolyMeshBaker.java tidak ada"; exit 1; }
echo "Selesai: poly_mesh + mode hemat RAM aktif."
