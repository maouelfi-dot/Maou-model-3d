package com.micaftic.morpher.core.config;

import com.micaftic.morpher.config.GeneralConfig;
import com.micaftic.morpher.config.ServerConfig;
import com.micaftic.morpher.core.render.NativeSimdPolicy;
import net.minecraftforge.common.ForgeConfigSpec;

import java.util.List;

/**
 * Stable policy boundary over the legacy Forge Config API values.
 * The legacy key names remain defined by the existing config classes.
 */
public final class ConfigPolicies {
    private ConfigPolicies() {
    }

    public static Snapshot snapshot() {
        return new Snapshot(render(), memory(), diagnostics(), privacy(), network());
    }

    public static RenderPolicy render() {
        return new RenderPolicy(
                bool(GeneralConfig.DISABLE_SELF_MODEL, false),
                bool(GeneralConfig.DISABLE_OTHER_MODEL, false),
                bool(GeneralConfig.DISABLE_SELF_HANDS, false),
                bool(GeneralConfig.DISABLE_PROJECTILE_MODEL, false),
                bool(GeneralConfig.DISABLE_VEHICLE_MODEL, false),
                bool(GeneralConfig.DISABLE_EXTERNAL_FP_ANIM, false),
                bool(GeneralConfig.USE_COMPATIBILITY_RENDERER, false),
                bool(GeneralConfig.USE_GPU_RENDERER, true),
                bool(GeneralConfig.DISABLE_MODEL_GLOW_IN_SHADERPACK, true),
                bool(GeneralConfig.ANIMATION_DISTANCE_LOD, false) || isLowMemoryHeap());
    }

    /** Face-cull escape hatch; default false keeps upstream bake semantics. */
    public static boolean disableModelFaceCulling() {
        return bool(GeneralConfig.DISABLE_MODEL_FACE_CULLING, false);
    }

    /** Developer-options panel-state writeback gate; default false keeps state immutable from the UI. */
    public static boolean developerStateWriteback() {
        return bool(GeneralConfig.DEVELOPER_STATE_WRITEBACK, false);
    }
    /**
     * Model picker presentation default. The model screen seeds its per-session style from this
     * once and afterwards remembers the user's in-screen override.
     */
    public static GeneralConfig.ModelPickerStyle modelPickerStyle() {
        GeneralConfig.ModelPickerStyle style = value(GeneralConfig.MODEL_PICKER_STYLE, GeneralConfig.ModelPickerStyle.AUTO);
        return style == null ? GeneralConfig.ModelPickerStyle.AUTO : style;
    }

    public static FeaturePolicy features() {
        return new FeaturePolicy(false, false, false, true, bool(GeneralConfig.ANIMATION_ROULETTE_DEBUG_LOG, false));
    }

    public static MemoryPolicy memory() {
        int audioCache = integer(GeneralConfig.AUDIO_CACHE_MAX_BYTES, 64 * 1024 * 1024);
        int gpuModels = integer(GeneralConfig.MAX_CACHED_GPU_MODELS, 24);
        int cpuModels = integer(GeneralConfig.MAX_RESIDENT_CPU_MODELS, 64);
        int ttlSeconds = integer(GeneralConfig.UNUSED_MODEL_TTL_SECONDS, 300);
        if (isLowMemoryHeap()) {
            // Low-RAM devices (e.g. 2 GB phones): keep far fewer models/audio resident and release unused ones sooner.
            audioCache = Math.min(audioCache, 8 * 1024 * 1024);
            gpuModels = Math.min(gpuModels, 4);
            cpuModels = Math.min(cpuModels, 6);
            ttlSeconds = Math.min(ttlSeconds, 60);
        }
        return new MemoryPolicy(audioCache, gpuModels, bool(GeneralConfig.LAZY_MODEL_LOADING, true), cpuModels, ttlSeconds);
    }

    /** True when the JVM max heap is 1.5 GB or less (typical for 2 GB phones running Minecraft). */
    public static boolean isLowMemoryHeap() {
        return Runtime.getRuntime().maxMemory() <= 1536L * 1024L * 1024L;
    }

    public static DiagnosticsPolicy diagnostics() {
        return new DiagnosticsPolicy(
                bool(GeneralConfig.ANIMATION_FRAME_PROFILER, false),
                bool(GeneralConfig.ANIMATION_DEBUG_LOG, false),
                bool(GeneralConfig.WARN_REPEATED_ANIMATION_EVALUATION, true),
                bool(GeneralConfig.RESOURCE_STATION_MONITOR_LOG, false),
                bool(GeneralConfig.NETWORK_ONLINE_DEBUG_LOG, false),
                bool(GeneralConfig.MODEL_MEMORY_PROFILER, false),
                bool(GeneralConfig.MODEL_IMPORT_PERFORMANCE_LOG, false),
                bool(GeneralConfig.INPUT_STATE_DEBUG_LOG, false));
    }

    public static PrivacyPolicy privacy() {
        return new PrivacyPolicy(bool(GeneralConfig.PRIVACY_MODE, false));
    }

    public static NetworkPolicy network() {
        return new NetworkPolicy(
                value(ServerConfig.DEFAULT_MODEL_ID, "default"),
                value(ServerConfig.DEFAULT_MODEL_TEXTURE, "default"),
                bool(ServerConfig.CAN_SWITCH_MODEL, true),
                bool(ServerConfig.ALLOW_MODEL_UPLOAD, true),
                integer(ServerConfig.MODEL_UPLOAD_MAX_MB, 128),
                integer(ServerConfig.MODEL_UPLOAD_CHUNKS_PER_TICK, 4),
                List.copyOf(value(ServerConfig.CLIENT_NOT_DISPLAY_MODELS, List.of())),
                integer(ServerConfig.THREAD_COUNT, 0),
                bool(ServerConfig.ENABLE_GLOBAL_BANDWIDTH_LIMIT, false),
                integer(ServerConfig.BANDWIDTH_LIMIT, 5),
                integer(ServerConfig.PLAYER_SYNC_TIMEOUT, 0),
                bool(ServerConfig.LOW_BANDWIDTH_USAGE, false),
                integer(ServerConfig.ACCEPT_SOUND_FX, 0));
    }

    public static GraphicsPolicy graphics() {
        return new GraphicsPolicy(
                nativeSimdPolicy(value(GeneralConfig.NATIVE_SIMD_POLICY, GeneralConfig.NativeSimdPolicy.AGGRESSIVE)),
                bool(GeneralConfig.EXPERIMENTAL_JAVA_VECTOR_RENDERER, false));
    }

    private static NativeSimdPolicy nativeSimdPolicy(GeneralConfig.NativeSimdPolicy value) {
        return value == null ? NativeSimdPolicy.AGGRESSIVE : NativeSimdPolicy.valueOf(value.name());
    }

    public static AudioPolicy audio() {
        return new AudioPolicy(decimal(GeneralConfig.SOUND_VOLUME, 100.0));
    }

    private static boolean bool(ForgeConfigSpec.BooleanValue value, boolean fallback) {
        try {
            return value == null ? fallback : value.get();
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private static int integer(ForgeConfigSpec.IntValue value, int fallback) {
        try {
            return value == null ? fallback : value.get();
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private static double decimal(ForgeConfigSpec.DoubleValue value, double fallback) {
        try {
            return value == null ? fallback : value.get();
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private static <T> T value(ForgeConfigSpec.ConfigValue<T> value, T fallback) {
        try {
            T result = value == null ? null : value.get();
            return result == null ? fallback : result;
        } catch (Exception ignored) {
            return fallback;
        }
    }

    public record FeaturePolicy(boolean experimentalFallbackElytraWithoutLocator, boolean experimentalEnableElytraForDefaultAndMiscModels, boolean vulkanExperimentalCapabilityProbe, boolean worldRendererHook, boolean animationRouletteDebugLog) {
    }

    public record Snapshot(RenderPolicy render, MemoryPolicy memory, DiagnosticsPolicy diagnostics,
                           PrivacyPolicy privacy, NetworkPolicy network) {
    }

    public record RenderPolicy(boolean disableSelfModel, boolean disableOtherModel, boolean disableSelfHands,
                               boolean disableProjectileModel, boolean disableVehicleModel,
                               boolean disableExternalFirstPersonAnimation, boolean useCompatibilityRenderer,
                               boolean useGpuRenderer, boolean disableModelGlowInShaderpack,
                               boolean animationDistanceLod) {
    }

    public record MemoryPolicy(int audioCacheMaxBytes, int maxCachedGpuModels, boolean lazyModelLoading,
                               int maxResidentCpuModels, int unusedModelTtlSeconds) {
    }

    public record DiagnosticsPolicy(boolean animationFrameProfiler, boolean animationDebugLog,
                                    boolean warnRepeatedAnimationEvaluation, boolean resourceStationMonitorLog,
                                    boolean networkOnlineDebugLog, boolean modelMemoryProfiler,
                                    boolean modelImportPerformanceLog, boolean inputStateDebugLog) {
    }

    public record PrivacyPolicy(boolean enabled) {
    }

    public record NetworkPolicy(String defaultModelId, String defaultModelTexture, boolean canSwitchModel,
                                boolean allowModelUpload, int modelUploadMaxMiB, int modelUploadChunksPerTick,
                                List<String> clientNotDisplayModels, int threadCount,
                                boolean globalBandwidthLimit, int bandwidthLimitMbps, int playerSyncTimeoutSeconds,
                                boolean lowBandwidthUsage, int acceptSoundFx) {
    }

    public record GraphicsPolicy(NativeSimdPolicy nativeSimdPolicy,
                                 boolean experimentalJavaVectorRenderer) {
    }

    public record AudioPolicy(double soundVolumePercent) {
    }
}
