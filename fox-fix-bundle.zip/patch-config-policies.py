import sys, re, pathlib
cands = [pathlib.Path("common/src/main/java/com/micaftic/morpher/core/config/ConfigPolicies.java"),
         pathlib.Path("fabric/src/main/java/com/micaftic/morpher/core/config/ConfigPolicies.java")]
found = [c for c in cands if c.exists()]
assert len(found) == 1, f"ConfigPolicies harus ada tepat satu, ditemukan: {found}"
p = found[0]
s = p.read_text(encoding="utf-8")
if "isLowMemoryHeap" in s:
    print(f"ConfigPolicies ({p.parts[0]}) sudah ter-patch, dilewati."); sys.exit(0)

# 1) render(): ANIMATION_DISTANCE_LOD -> juga aktif saat heap kecil
pat_lod = re.compile(r"bool\(GeneralConfig\.ANIMATION_DISTANCE_LOD, false\)(\)\s*;|\)\s*\)\s*;|\);)")
m = re.search(r"bool\(GeneralConfig\.ANIMATION_DISTANCE_LOD, false\)", s)
assert m and s.count("bool(GeneralConfig.ANIMATION_DISTANCE_LOD, false)") == 1, "ANIMATION_DISTANCE_LOD tidak unik/tidak ada"
s = s.replace("bool(GeneralConfig.ANIMATION_DISTANCE_LOD, false)", "bool(GeneralConfig.ANIMATION_DISTANCE_LOD, false) || isLowMemoryHeap()")

# 2) memory(): format satu baris (26.x) atau banyak baris (1.21.1)
pat = re.compile(r"    public static MemoryPolicy memory\(\) \{.*?return new MemoryPolicy\(.*?\);\s*\}\n", re.S)
m = pat.search(s)
assert m, "memory() tidak ditemukan"
body = m.group(0)
def default_of(name, fallback):
    mm = re.search(r"integer\(GeneralConfig\." + name + r",\s*([^)]+?)\)", body)
    return mm.group(1).strip() if mm else fallback
audio = default_of("AUDIO_CACHE_MAX_BYTES", "64 * 1024 * 1024")
gpu = default_of("MAX_CACHED_GPU_MODELS", "24")
cpu = default_of("MAX_RESIDENT_CPU_MODELS", "64")
ttl = default_of("UNUSED_MODEL_TTL_SECONDS", "300")
new_mem = f'''    public static MemoryPolicy memory() {{
        int audioCache = integer(GeneralConfig.AUDIO_CACHE_MAX_BYTES, {audio});
        int gpuModels = integer(GeneralConfig.MAX_CACHED_GPU_MODELS, {gpu});
        int cpuModels = integer(GeneralConfig.MAX_RESIDENT_CPU_MODELS, {cpu});
        int ttlSeconds = integer(GeneralConfig.UNUSED_MODEL_TTL_SECONDS, {ttl});
        if (isLowMemoryHeap()) {{
            // HP RAM kecil (mis. 2 GB): simpan lebih sedikit model/audio di memori dan lepas lebih cepat.
            audioCache = Math.min(audioCache, 8 * 1024 * 1024);
            gpuModels = gpuModels <= 0 ? 4 : Math.min(gpuModels, 4); // 0 = tak terbatas
            cpuModels = Math.min(cpuModels, 6);
            ttlSeconds = Math.min(ttlSeconds, 60);
        }}
        return new MemoryPolicy(audioCache, gpuModels, bool(GeneralConfig.LAZY_MODEL_LOADING, true), cpuModels, ttlSeconds);
    }}

    /** True bila heap maksimum JVM <= 1,5 GB (umum di HP 2 GB yang menjalankan Minecraft). */
    public static boolean isLowMemoryHeap() {{
        return Runtime.getRuntime().maxMemory() <= 1536L * 1024L * 1024L;
    }}
'''
s = s[:m.start()] + new_mem + s[m.end():]
p.write_text(s, encoding="utf-8")
print(f"ConfigPolicies ({p.parts[0]}/) berhasil di-patch: mode hemat RAM aktif.")
