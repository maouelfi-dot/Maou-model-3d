import sys, re, pathlib
p = pathlib.Path("fabric/src/main/java/com/micaftic/morpher/core/config/ConfigPolicies.java")
s = p.read_text(encoding="utf-8")
if "isLowMemoryHeap" in s:
    print("ConfigPolicies (fabric) sudah ter-patch, dilewati."); sys.exit(0)

old_lod = "bool(GeneralConfig.ANIMATION_DISTANCE_LOD, false)); }"
new_lod = "bool(GeneralConfig.ANIMATION_DISTANCE_LOD, false) || isLowMemoryHeap()); }"
assert s.count(old_lod) == 1, "baris render() tidak ditemukan"
s = s.replace(old_lod, new_lod)

pat = re.compile(r"    public static MemoryPolicy memory\(\) \{ return new MemoryPolicy\(.*?\); \}\n", re.S)
m = pat.search(s)
assert m, "baris memory() tidak ditemukan"
new_mem = '''    public static MemoryPolicy memory() {
        int audioCache = integer(GeneralConfig.AUDIO_CACHE_MAX_BYTES, 64 * 1024 * 1024);
        int gpuModels = integer(GeneralConfig.MAX_CACHED_GPU_MODELS, 0);
        int cpuModels = integer(GeneralConfig.MAX_RESIDENT_CPU_MODELS, 64);
        int ttlSeconds = integer(GeneralConfig.UNUSED_MODEL_TTL_SECONDS, 300);
        if (isLowMemoryHeap()) {
            // HP RAM kecil (mis. 2 GB): simpan lebih sedikit model/audio di memori dan lepas lebih cepat.
            audioCache = Math.min(audioCache, 8 * 1024 * 1024);
            gpuModels = gpuModels <= 0 ? 4 : Math.min(gpuModels, 4); // 0 = tak terbatas di Fabric
            cpuModels = Math.min(cpuModels, 6);
            ttlSeconds = Math.min(ttlSeconds, 60);
        }
        return new MemoryPolicy(audioCache, gpuModels, bool(GeneralConfig.LAZY_MODEL_LOADING, true), cpuModels, ttlSeconds);
    }

    /** True bila heap maksimum JVM <= 1,5 GB (umum di HP 2 GB yang menjalankan Minecraft). */
    public static boolean isLowMemoryHeap() {
        return Runtime.getRuntime().maxMemory() <= 1536L * 1024L * 1024L;
    }
'''
s = s[:m.start()] + new_mem + s[m.end():]
p.write_text(s, encoding="utf-8")
print("ConfigPolicies (fabric) berhasil di-patch: mode hemat RAM aktif.")
