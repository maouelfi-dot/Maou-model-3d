import sys, pathlib

def edit(path, pairs, marker):
    p = pathlib.Path(path)
    assert p.exists(), f"{path} tidak ditemukan"
    s = p.read_text(encoding="utf-8")
    if marker in s:
        print(f"{p.name}: sudah ter-patch, dilewati."); return
    for old, new in pairs:
        assert s.count(old) == 1, f"{p.name}: potongan kode tidak unik/tidak ada: {old[:70]!r} (ditemukan {s.count(old)}x)"
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8")
    print(f"{p.name}: berhasil di-patch.")

C = "common/src/main/java/"

edit(C + "com/micaftic/morpher/resource/pojo/RawYsmModel.java", [(
    "        public float[] normal = new float[3];\n",
    "        public float[] normal = new float[3];\n"
    "        /** Optional smooth normals, 12 floats (xyz per vertex); null = flat shading with {@link #normal}. */\n"
    "        public float[] vertexNormals;\n")], "vertexNormals")

edit(C + "com/elfmcys/yesstevemodel/geckolib3/geo/render/built/GeoModel.java", [(
    "        public float normalX, normalY, normalZ;\n",
    "        public float normalX, normalY, normalZ;\n"
    "        /** Optional smooth normals, 12 floats (xyz per vertex); null = flat shading with normalX/Y/Z. */\n"
    "        public float[] vertexNormals;\n\n"
    "        public float vnx(int v) { return vertexNormals != null ? vertexNormals[v * 3] : normalX; }\n"
    "        public float vny(int v) { return vertexNormals != null ? vertexNormals[v * 3 + 1] : normalY; }\n"
    "        public float vnz(int v) { return vertexNormals != null ? vertexNormals[v * 3 + 2] : normalZ; }\n")], "vertexNormals")

edit(C + "com/micaftic/morpher/resource/bundle/GeometryBaker.java", [(
    "                    bq.setNormal(rf.normal[0], rf.normal[1], rf.normal[2]);\n",
    "                    bq.setNormal(rf.normal[0], rf.normal[1], rf.normal[2]);\n"
    "                    if (rf.vertexNormals != null && rf.vertexNormals.length >= 12) {\n"
    "                        bq.vertexNormals = rf.vertexNormals;\n"
    "                    }\n")], "vertexNormals")

edit(C + "com/micaftic/morpher/core/gpu/GpuMeshDataBuilder.java", [
    ("int normal = packNormal(quad.normalX, quad.normalY, quad.normalZ);",
     "int flatNormal = packNormal(quad.normalX, quad.normalY, quad.normalZ);"),
    ("vertices.putInt(normal);",
     "vertices.putInt(quad.vertexNormals == null ? flatNormal : packNormal(quad.vnx(v), quad.vny(v), quad.vnz(v)));"),
], "flatNormal")

edit(C + "com/micaftic/morpher/core/gpu/Blaze3DModelMeshBuilder.java", [
    ("vertices.put(packSnorm8(quad.normalX));", "vertices.put(packSnorm8(quad.vnx(v)));"),
    ("vertices.put(packSnorm8(quad.normalY));", "vertices.put(packSnorm8(quad.vny(v)));"),
    ("vertices.put(packSnorm8(quad.normalZ));", "vertices.put(packSnorm8(quad.vnz(v)));"),
], "quad.vnx(v)")

BR = "                            "
edit(C + "com/elfmcys/yesstevemodel/geckolib3/geo/ModelRendererBridge.java", [
    ("                        for (int v = 0; v < 4; v++) {\n" + BR + "vertexConsumer.addVertex(scratch.vectorX[v]",
     "                        for (int v = 0; v < 4; v++) {\n"
     + BR + "if (quad.vertexNormals != null) { tempNorm.set(quad.vnx(v), quad.vny(v), quad.vnz(v)).mul(globalNormalMat).normalize(); }\n"
     + BR + "vertexConsumer.addVertex(scratch.vectorX[v]"),
    ("                        for (int v = 0; v < 4; v++) {\n" + BR + "tempPos.set(quad.x(v), quad.y(v), quad.z(v), 1.0f).mul(globalBoneMat);",
     "                        for (int v = 0; v < 4; v++) {\n"
     + BR + "if (quad.vertexNormals != null) { tempNorm.set(quad.vnx(v), quad.vny(v), quad.vnz(v)).mul(globalNormalMat).normalize(); }\n"
     + BR + "tempPos.set(quad.x(v), quad.y(v), quad.z(v), 1.0f).mul(globalBoneMat);"),
], "quad.vnx(v)")
